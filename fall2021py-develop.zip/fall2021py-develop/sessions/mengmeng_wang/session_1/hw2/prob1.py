#!/usr/bin/env python3

#Given two numbers (arbitrary chosen), A = 14, B = 41, exchange values without creating another variable.
A=14
B=41

B=B-A
A=B+A
B=A-B
print(A,B)

